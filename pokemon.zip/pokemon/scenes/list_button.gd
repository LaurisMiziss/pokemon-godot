extends Button

var state
var type
signal press(state, type)


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass


func setup(menu_state, button_type) -> void:
	@warning_ignore("incompatible_ternary")
	var data = Global.monster_data if menu_state == Global.State.SWAP else Global.item_data
	$MarginContainer/HBoxContainer/Label.text = data[button_type]['name']
	$MarginContainer/HBoxContainer/TextureRect.texture = load(data[button_type]['icon'])
	state = menu_state
	type = button_type
	
	
func _on_pressed() -> void:
	press.emit(state, type)
