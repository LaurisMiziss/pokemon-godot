extends Button

var state
var type
signal press(state, type)


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass


func _on_pressed() -> void:
	press.emit(state, type)


func setup(menu_state: Global.State, button_type, button_text: String) -> void:
	text = button_text
	state = menu_state
	type = button_type
