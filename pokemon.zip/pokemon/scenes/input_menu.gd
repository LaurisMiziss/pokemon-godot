extends Control

var grid_button_scene: PackedScene = preload("res://scenes/grid_button.tscn")
var list_button_scene: PackedScene = preload("res://scenes/list_button.tscn")
const main_buttons = {
	Global.State.ATTACK: "Attack",
	Global.State.DEFEND: "Defend",
	Global.State.SWAP: "Swap",
	Global.State.ITEM: "Item"
}
var current_state: Global.State: set = state_handler
signal selected(state: Global.State, type)

func _ready() -> void:
	current_state = Global.State.MAIN


func _process(_delta: float) -> void:
	pass


func _input(_event: InputEvent) -> void:
	if Input.is_action_just_pressed("ui_cancel"):
		current_state = Global.State.MAIN


func create_grid_buttons(state: Global.State, data: Dictionary) -> void:
	$ScrollContainer.visible = false
	$GridContainer.visible = true
	for i in $GridContainer.get_children():
		i.queue_free()
		
	for key in data:
		var grid_button = grid_button_scene.instantiate() as Button
		grid_button.setup(state, key, data[key])
		$GridContainer.add_child(grid_button)
		grid_button.connect("press", button_handler)
		
	await get_tree().process_frame
	$GridContainer.get_child(0).grab_focus()


func creat_list_buttons(state: Global.State, data: Array) -> void:
	$GridContainer.visible = false
	$ScrollContainer.visible = true
	for i in $ScrollContainer/VBoxContainer.get_children():
		i.queue_free()

	for i in data:
		var list_button = list_button_scene.instantiate() as Button
		list_button.setup(state, i)
		$ScrollContainer/VBoxContainer.add_child(list_button)
		list_button.press.connect(button_handler)
	await get_tree().process_frame
	$ScrollContainer/VBoxContainer.get_child(0).grab_focus()


func button_handler(state, type) -> void:
	if state == Global.State.MAIN:
		current_state = type
	else:
		selected.emit(state, type)
		
		
func state_handler(new_state) -> void:
	current_state = new_state
	
	match new_state:
		Global.State.MAIN:
			create_grid_buttons(Global.State.MAIN, main_buttons)
		Global.State.ATTACK:
			var monster_attacks = Global.monster_data[Global.current_monster]['attacks']
			create_grid_buttons(
				Global.State.ATTACK, 
			{
				monster_attacks[0]: Global.attack_data[monster_attacks[0]]['name'],
				monster_attacks[1]: Global.attack_data[monster_attacks[1]]['name'],
				monster_attacks[2]: Global.attack_data[monster_attacks[2]]['name'],
				monster_attacks[3]: Global.attack_data[monster_attacks[3]]['name']
			})
		Global.State.DEFEND:
			selected.emit(Global.State.DEFEND, 0)
		Global.State.SWAP:
			creat_list_buttons(Global.State.SWAP, Global.monsters)
		Global.State.ITEM:
			creat_list_buttons(Global.State.ITEM, Global.items)


func _on_visibility_changed() -> void:
	current_state = Global.State.MAIN
