extends Control

signal defeated(message: String)
@onready var label := $PanelContainer/MarginContainer/VBoxContainer/Label
@onready var progress_bar := $PanelContainer/MarginContainer/VBoxContainer/ProgressBar

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass


func setup(monster: Global.Monster, _is_player = true) -> void:
	var monster_data = Global.monster_data[monster]
	label.text = monster_data["name"]
	progress_bar.max_value = monster_data["max health"]
	progress_bar.value = monster_data["max health"]

func update(data) -> void:
	progress_bar.value -= data["amount"]
	if progress_bar.value <= 0:
		defeated.emit("defeated")
