extends Control

@export var animation_index	: int


func _ready() -> void:
	# player monster setup
	$AttackSprite.visible = false
	Global.current_monster = Global.monsters.pop_at(0)
	$Stats/PlayerStats.setup(Global.current_monster)
	
	# enemy monster setup
	monster_setup()
	
	
func _process(_delta: float) -> void:
	var atlas = $Monsters/EnemyMonster.texture as AtlasTexture
	var pos_y = 0 if $InputMenu.visible else 96
	atlas.region = Rect2i(Vector2i(96 * animation_index, pos_y), Vector2i(96, 96))


func _on_input_menu_selected(state: int, type: Variant) -> void:
	$InputMenu.hide()
	$TurnTimer.start()
	match state:
		Global.State.ATTACK:
			var target = $Monsters/EnemyMonster if Global.attack_data[type]['target'] else $Monsters/PlayerMonster
			attack(target, type)
		Global.State.SWAP:
			Global.monsters.append(Global.current_monster)
			var back_texture = Global.monster_data[type]["back texture"]
			$Monsters/PlayerMonster.texture = load(back_texture)
			Global.monsters.erase(type)
			Global.current_monster = type
			$Stats/PlayerStats.setup(Global.current_monster)
		Global.State.SWAP:
			pass
		Global.State.ITEM:
			var target = $Monsters/EnemyMonster if Global.item_data[type]['target'] else $Monsters/PlayerMonster
			use_item(target, type)

func attack(target: TextureRect, attack_type: Global.Attack):
	$AttackSprite.visible = true
	$AttackSprite.frame = 0
	if target == $Monsters/PlayerMonster:
		$Stats/PlayerStats.update(Global.attack_data[attack_type])
	else:
		$Stats/MonsterStats.update(Global.attack_data[attack_type])
	$AttackSprite.texture = load(Global.attack_data[attack_type]["animation"])
	var rect: Rect2 = target.get_rect()
	$AttackSprite.global_position = rect.position + rect.size / 2
	var tween = create_tween()
	tween.tween_property($AttackSprite, "frame", 3, 0.5).from(0)
	tween.tween_property($AttackSprite, "visible", false, 0.0)
	
	
func update_index() -> void:
	if animation_index < 3:
		animation_index += 1
	else:
		animation_index = 0
		
		
func monster_setup() -> void:
	Global.current_enemy = Global.Monster.values().pick_random()
	var front_texture = Global.monster_data[Global.current_enemy]["front texture"]
	var new_atlas: AtlasTexture = AtlasTexture.new()
	new_atlas.atlas = load(front_texture)
	$Monsters/EnemyMonster.texture = new_atlas
	$Stats/MonsterStats.setup(Global.current_enemy, false)
	
func _on_player_stats_defeated(_message: String) -> void:
	Global.current_monster = Global.monsters.pop_at(0)
	var back_texture = Global.monster_data[Global.current_monster]["back texture"]
	$Monsters/PlayerMonster.texture = load(back_texture)
	$Stats/PlayerStats.setup(Global.current_monster)


func _on_monster_stats_defeated(_message: String) -> void:
	monster_setup()


func _on_turn_timer_timeout() -> void:
	var attack_enum: Global.Attack = Global.monster_data[Global.current_enemy]["attacks"].pick_random()
	var attack_type = Global.attack_data[attack_enum]
	var target: TextureRect = $Monsters/PlayerMonster if attack_type["target"] != 0 else $Monsters/EnemyMonster
	attack(target, attack_enum)
	$AnimationPlayer.play("attack")
	

func use_item(target: TextureRect, type: Global.Item) -> void:
	if target == $Monsters/PlayerMonster:
		$Stats/PlayerStats.update(Global.item_data[type])
	else:
		$Stats/MonsterStats.update(Global.item_data[type])


func _on_animation_player_animation_finished(anim_name: StringName) -> void:
	if anim_name == "attack":
		$InputMenu.show()
		$AnimationPlayer.play("idle")
